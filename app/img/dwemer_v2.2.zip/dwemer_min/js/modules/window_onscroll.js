import { fixedHeader, header, headerHeight } from "../modules/fixed-header.js";

const windowOnscroll = () => {
    const section = document.querySelectorAll(".section");
    const navLinks = Array.from(document.querySelectorAll(".nav__link"));
    const navLists = document.querySelectorAll(".nav__list");
    const logos = document.querySelectorAll(".logo");
    const homeLink = document.getElementById("home-link");

    let blockingScrollListener;
    let lockHome;
    let lockAbout;
    let lockServices;
    let lockJoin;
    let blockingTime;

    const removeActiveLink = () => navLinks.forEach((link) => link.classList.remove("_active"));
    const activateScrollListenerBlocking = () => {
        blockingScrollListener = true;
        blockingTime = setTimeout(() => {
            blockingScrollListener = false;
        }, 2000);
    };

    // blocking scroll listener, when clicking on the logo
    logos.forEach((list) => {
        list.addEventListener("click", () => {
            removeActiveLink();
            clearTimeout(blockingTime);
            activateScrollListenerBlocking();
            homeLink.classList.add("_active");
        });
    });

    // blocking scroll listener, when clicking on the menu link
    navLists.forEach((list) => {
        list.addEventListener("click", ({ target }) => {
            if (target.closest(".nav__link")) {
                clearTimeout(blockingTime);
                activateScrollListenerBlocking();
            } else {
                return;
            }
        });
    });

    const sectionPositionsArray = [];
    // getting the top position of each section and putting it in the array
    section.forEach((section) => {
        sectionPositionsArray.push(section.getBoundingClientRect().top + window.pageYOffset);
    });
    // set them in a variable
    let [homePosition, aboutPosition, servicesPosition, joinPosition] = sectionPositionsArray;

    window.addEventListener("scroll", () => {
        // fixed header function
        fixedHeader();

        if (!blockingScrollListener) {
            // position of our fixed header
            let headerPosition = header.getBoundingClientRect().top + window.pageYOffset;

            // associate a specific menu item with a specific section
            if (headerPosition >= homePosition - headerHeight && headerPosition <= aboutPosition - headerHeight) {
                if (!lockHome) {
                    const link = document.getElementById(`home-link`);
                    removeActiveLink();
                    link.classList.add("_active");
                    lockHome = true;
                    lockAbout = false;
                    lockServices = false;
                    lockJoin = false;
                }
            } else if (headerPosition >= aboutPosition - headerHeight && headerPosition <= servicesPosition - headerHeight) {
                if (!lockAbout) {
                    const link = document.getElementById(`about-link`);
                    removeActiveLink();
                    link.classList.add("_active");
                    lockAbout = true;
                    lockHome = false;
                    lockServices = false;
                    lockJoin = false;
                }
            } else if (headerPosition >= servicesPosition - headerHeight && headerPosition <= joinPosition - headerHeight) {
                if (!lockServices) {
                    const link = document.getElementById(`services-link`);
                    removeActiveLink();
                    link.classList.add("_active");
                    lockServices = true;
                    lockHome = false;
                    lockAbout = false;
                    lockJoin = false;
                }
            } else if (headerPosition >= joinPosition - headerHeight) {
                if (!lockJoin) {
                    const link = document.getElementById(`join-link`);
                    removeActiveLink();
                    link.classList.add("_active");
                    lockJoin = true;
                    lockServices = false;
                    lockAbout = false;
                    lockHome = false;
                }
            }
        }
    });
};

export default windowOnscroll;
