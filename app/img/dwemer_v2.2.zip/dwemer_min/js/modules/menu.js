const menu = () => {
    const iconMenu = document.querySelector(".nav__icon");
    const navigation = document.querySelector(".nav__body--header");
    const navListHeader = document.querySelector(".nav__list--header");
    const navListFooter = document.querySelector(".nav__list--footer");
    const navLinks = Array.from(document.querySelectorAll(".nav__link"));
    const removeActiveLink = () => navLinks.forEach((link) => link.classList.remove("_active"));

    // show hide menu
    iconMenu.addEventListener("click", () => {
        document.body.classList.toggle("_lock");
        iconMenu.classList.toggle("_active");
        navigation.classList.toggle("_active");
    });

    // add the active class to the header menu item
    navListHeader.addEventListener("click", ({ target }) => {
        if (target.closest(".nav__link")) {
            removeActiveLink();
            target.classList.add("_active");
            if (innerWidth <= 950) {
                document.body.classList.remove("_lock");
                iconMenu.classList.remove("_active");
                navigation.classList.remove("_active");
            }
        } else {
            return;
        }
    });

    // add the active class to the header menu item, when clicking on a similar item in the footer
    navListFooter.addEventListener("click", ({ target }) => {
        if (target.closest(".nav__link")) {
            const targetHash = target.hash.substring(1);
            const headerLinkId = `${targetHash + "-link"}`;
            const link = document.getElementById(`${headerLinkId}`);

            removeActiveLink();

            link.classList.add("_active");
        } else {
            return;
        }
    });
};

export default menu;
