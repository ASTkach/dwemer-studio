const header = document.querySelector(".header");
const headerHeight = header.scrollHeight;

const fixedHeader = () => {
    const pageWrapper = document.querySelector(".wrapper");

    if (window.scrollY > headerHeight) {
        header.classList.add("_fixed");
        pageWrapper.style.paddingTop = headerHeight + "px";
    } else if (window.scrollY === 0) {
        header.classList.remove("_fixed");
        pageWrapper.style.paddingTop = null;
    }
};

export { fixedHeader, header, headerHeight };
