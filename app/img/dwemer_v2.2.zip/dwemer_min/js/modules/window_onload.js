import animationObserver from "../modules/animation_observer.js";

const initialMenuLink = document.getElementById("home-link");

const windowOnload = () => {
    window.addEventListener("load", () => {
        animationObserver();
        initialMenuLink.classList.add("_active");
    });
};

export default windowOnload;
