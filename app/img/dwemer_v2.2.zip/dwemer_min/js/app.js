import windowOnscroll from "./modules/window_onscroll.js";
import windowOnload from "./modules/window_onload.js";
import menu from "./modules/menu.js";
import marqueeTouch from "./modules/marquee_toush.js";

windowOnload();
windowOnscroll();
menu();
marqueeTouch();
